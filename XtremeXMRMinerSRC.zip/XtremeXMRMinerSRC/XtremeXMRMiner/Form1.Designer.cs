﻿namespace XtremeMinergateMiner
{
    partial class Form1
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.cbHide = new System.Windows.Forms.CheckBox();
            this.btnStopMiners = new System.Windows.Forms.Button();
            this.txtStatus = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnQuit = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.txtXmrigLog = new System.Windows.Forms.TextBox();
            this.lblXmrigLog = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtXmrminerLog = new System.Windows.Forms.TextBox();
            this.panelXmrigSettings = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.numericNumberOfThreads = new System.Windows.Forms.NumericUpDown();
            this.lblCpuPriority = new System.Windows.Forms.Label();
            this.numericCpuPriority = new System.Windows.Forms.NumericUpDown();
            this.checkboxSafe = new System.Windows.Forms.CheckBox();
            this.lblXmrigSettings = new System.Windows.Forms.Label();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.linkLabel2 = new System.Windows.Forms.LinkLabel();
            this.linkLabel3 = new System.Windows.Forms.LinkLabel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panelXmrigSettings.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericNumberOfThreads)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericCpuPriority)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(13, 13);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "Start miner";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(154, 15);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(316, 20);
            this.txtEmail.TabIndex = 1;
            // 
            // cbHide
            // 
            this.cbHide.AutoSize = true;
            this.cbHide.Location = new System.Drawing.Point(476, 19);
            this.cbHide.Name = "cbHide";
            this.cbHide.Size = new System.Drawing.Size(95, 17);
            this.cbHide.TabIndex = 2;
            this.cbHide.Text = "Hide after start";
            this.cbHide.UseVisualStyleBackColor = true;
            // 
            // btnStopMiners
            // 
            this.btnStopMiners.Location = new System.Drawing.Point(13, 42);
            this.btnStopMiners.Name = "btnStopMiners";
            this.btnStopMiners.Size = new System.Drawing.Size(75, 23);
            this.btnStopMiners.TabIndex = 3;
            this.btnStopMiners.Text = "Stop miners";
            this.btnStopMiners.UseVisualStyleBackColor = true;
            this.btnStopMiners.Click += new System.EventHandler(this.btnStopMiners_Click);
            // 
            // txtStatus
            // 
            this.txtStatus.Location = new System.Drawing.Point(370, 45);
            this.txtStatus.Name = "txtStatus";
            this.txtStatus.Size = new System.Drawing.Size(100, 20);
            this.txtStatus.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(327, 48);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(37, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Status";
            // 
            // btnQuit
            // 
            this.btnQuit.Location = new System.Drawing.Point(496, 330);
            this.btnQuit.Name = "btnQuit";
            this.btnQuit.Size = new System.Drawing.Size(75, 23);
            this.btnQuit.TabIndex = 6;
            this.btnQuit.Text = "Quit";
            this.btnQuit.UseVisualStyleBackColor = true;
            this.btnQuit.Click += new System.EventHandler(this.btnQuit_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(122, 18);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(32, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Email";
            // 
            // txtXmrigLog
            // 
            this.txtXmrigLog.Location = new System.Drawing.Point(125, 164);
            this.txtXmrigLog.Multiline = true;
            this.txtXmrigLog.Name = "txtXmrigLog";
            this.txtXmrigLog.ReadOnly = true;
            this.txtXmrigLog.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtXmrigLog.Size = new System.Drawing.Size(446, 65);
            this.txtXmrigLog.TabIndex = 8;
            // 
            // lblXmrigLog
            // 
            this.lblXmrigLog.AutoSize = true;
            this.lblXmrigLog.Location = new System.Drawing.Point(65, 164);
            this.lblXmrigLog.Name = "lblXmrigLog";
            this.lblXmrigLog.Size = new System.Drawing.Size(54, 13);
            this.lblXmrigLog.TabIndex = 9;
            this.lblXmrigLog.Text = "Xmrig Log";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(50, 235);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 13);
            this.label3.TabIndex = 11;
            this.label3.Text = "XmMiner Log";
            // 
            // txtXmrminerLog
            // 
            this.txtXmrminerLog.Location = new System.Drawing.Point(125, 235);
            this.txtXmrminerLog.Multiline = true;
            this.txtXmrminerLog.Name = "txtXmrminerLog";
            this.txtXmrminerLog.ReadOnly = true;
            this.txtXmrminerLog.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtXmrminerLog.Size = new System.Drawing.Size(446, 65);
            this.txtXmrminerLog.TabIndex = 10;
            // 
            // panelXmrigSettings
            // 
            this.panelXmrigSettings.Controls.Add(this.label4);
            this.panelXmrigSettings.Controls.Add(this.numericNumberOfThreads);
            this.panelXmrigSettings.Controls.Add(this.lblCpuPriority);
            this.panelXmrigSettings.Controls.Add(this.numericCpuPriority);
            this.panelXmrigSettings.Controls.Add(this.checkboxSafe);
            this.panelXmrigSettings.Controls.Add(this.lblXmrigSettings);
            this.panelXmrigSettings.Location = new System.Drawing.Point(125, 99);
            this.panelXmrigSettings.Name = "panelXmrigSettings";
            this.panelXmrigSettings.Size = new System.Drawing.Size(446, 59);
            this.panelXmrigSettings.TabIndex = 12;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(299, 5);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(98, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Number of Threads";
            // 
            // numericNumberOfThreads
            // 
            this.numericNumberOfThreads.Location = new System.Drawing.Point(403, 3);
            this.numericNumberOfThreads.Maximum = new decimal(new int[] {
            32,
            0,
            0,
            0});
            this.numericNumberOfThreads.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericNumberOfThreads.Name = "numericNumberOfThreads";
            this.numericNumberOfThreads.Size = new System.Drawing.Size(44, 20);
            this.numericNumberOfThreads.TabIndex = 6;
            this.numericNumberOfThreads.Value = new decimal(new int[] {
            4,
            0,
            0,
            0});
            // 
            // lblCpuPriority
            // 
            this.lblCpuPriority.AutoSize = true;
            this.lblCpuPriority.Location = new System.Drawing.Point(180, 5);
            this.lblCpuPriority.Name = "lblCpuPriority";
            this.lblCpuPriority.Size = new System.Drawing.Size(63, 13);
            this.lblCpuPriority.TabIndex = 3;
            this.lblCpuPriority.Text = "CPU Priority";
            // 
            // numericCpuPriority
            // 
            this.numericCpuPriority.Location = new System.Drawing.Point(249, 3);
            this.numericCpuPriority.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.numericCpuPriority.Name = "numericCpuPriority";
            this.numericCpuPriority.Size = new System.Drawing.Size(44, 20);
            this.numericCpuPriority.TabIndex = 2;
            // 
            // checkboxSafe
            // 
            this.checkboxSafe.AutoSize = true;
            this.checkboxSafe.Location = new System.Drawing.Point(97, 4);
            this.checkboxSafe.Name = "checkboxSafe";
            this.checkboxSafe.Size = new System.Drawing.Size(77, 17);
            this.checkboxSafe.TabIndex = 1;
            this.checkboxSafe.Text = "Safe mode";
            this.checkboxSafe.UseVisualStyleBackColor = true;
            // 
            // lblXmrigSettings
            // 
            this.lblXmrigSettings.AutoSize = true;
            this.lblXmrigSettings.Location = new System.Drawing.Point(4, 4);
            this.lblXmrigSettings.Name = "lblXmrigSettings";
            this.lblXmrigSettings.Size = new System.Drawing.Size(74, 13);
            this.lblXmrigSettings.TabIndex = 0;
            this.lblXmrigSettings.Text = "Xmrig Settings";
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Location = new System.Drawing.Point(122, 343);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(183, 13);
            this.linkLabel1.TabIndex = 13;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "https://ichimoku-expert.blogspot.com";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // linkLabel2
            // 
            this.linkLabel2.AutoSize = true;
            this.linkLabel2.Location = new System.Drawing.Point(122, 330);
            this.linkLabel2.Name = "linkLabel2";
            this.linkLabel2.Size = new System.Drawing.Size(186, 13);
            this.linkLabel2.TabIndex = 14;
            this.linkLabel2.TabStop = true;
            this.linkLabel2.Text = "mailto:investdatasystems@yahoo.com";
            this.linkLabel2.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel2_LinkClicked);
            // 
            // linkLabel3
            // 
            this.linkLabel3.AutoSize = true;
            this.linkLabel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel3.Location = new System.Drawing.Point(8, 311);
            this.linkLabel3.Name = "linkLabel3";
            this.linkLabel3.Size = new System.Drawing.Size(591, 16);
            this.linkLabel3.TabIndex = 15;
            this.linkLabel3.TabStop = true;
            this.linkLabel3.Text = "My Ethereum Donation Address : 0x4ED81C78757fdC5D51529F843Dc6ad96F8B45F16";
            this.linkLabel3.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel3_LinkClicked);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Black;
            this.pictureBox2.Image = global::XtremeXMRMiner.Properties.Resources.fantomcoin;
            this.pictureBox2.Location = new System.Drawing.Point(68, 72);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(48, 44);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 17;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = global::XtremeXMRMiner.Properties.Resources.monero;
            this.pictureBox1.Location = new System.Drawing.Point(13, 72);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(49, 43);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 16;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ClientSize = new System.Drawing.Size(607, 362);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.linkLabel3);
            this.Controls.Add(this.linkLabel2);
            this.Controls.Add(this.linkLabel1);
            this.Controls.Add(this.panelXmrigSettings);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtXmrminerLog);
            this.Controls.Add(this.lblXmrigLog);
            this.Controls.Add(this.txtXmrigLog);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnQuit);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtStatus);
            this.Controls.Add(this.btnStopMiners);
            this.Controls.Add(this.cbHide);
            this.Controls.Add(this.txtEmail);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "Xtreme Minergate Miner v1.0 (Monero and Fantomcoin Version)";
            this.panelXmrigSettings.ResumeLayout(false);
            this.panelXmrigSettings.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericNumberOfThreads)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericCpuPriority)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.CheckBox cbHide;
        private System.Windows.Forms.Button btnStopMiners;
        private System.Windows.Forms.TextBox txtStatus;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnQuit;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtXmrigLog;
        private System.Windows.Forms.Label lblXmrigLog;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtXmrminerLog;
        private System.Windows.Forms.Panel panelXmrigSettings;
        private System.Windows.Forms.CheckBox checkboxSafe;
        private System.Windows.Forms.Label lblXmrigSettings;
        private System.Windows.Forms.Label lblCpuPriority;
        private System.Windows.Forms.NumericUpDown numericCpuPriority;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown numericNumberOfThreads;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.LinkLabel linkLabel2;
        private System.Windows.Forms.LinkLabel linkLabel3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}

